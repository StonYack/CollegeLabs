/*
 * mytasks.h
 *
 * Created: 1/4/2021 12:58:00 PM
 *  Author: sceverst
 */ 


#ifndef MYTASKS_H_
#define MYTASKS_H_

void taskSystemControl(void * pvParameters);
void HeartbeatTask(void * pvParameters);

#endif /* MYTASKS_H_ */