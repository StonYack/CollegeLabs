/*
 * swDriver.h
 *
 * Created: 1/12/2021 3:01:27 PM
 *  Author: Ston
 */ 


#ifndef SWDRIVER_H_
#define SWDRIVER_H_

void initializeSWDriver(void);
uint8_t readSW();
void Button1();
void Button2();
void Button3();
static inline void debounce(uint8_t state, uint8_t which);



#endif /* SWDRIVER_H_ */